package com.gojo.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.GraphicsMode;
import net.minecraft.client.option.ParticlesMode;

public class FpsMode {
    private static boolean saved = false;
    private static int pView, pBiome;
    private static ParticlesMode pParticles;
    private static boolean pShadows;
    private static GraphicsMode pGraphics;

    public static void apply(MinecraftClient mc) {
        GameOptions o = mc.options;
        if (Config.fpsMode) {
            if (!saved) {
                pView = o.getViewDistance().getValue();
                pBiome = o.getBiomeBlendRadius().getValue();
                pParticles = o.getParticles().getValue();
                pShadows = o.getEntityShadows().getValue();
                pGraphics = o.getGraphicsMode().getValue();
                saved = true;
            }
            o.getViewDistance().setValue(8);
            o.getBiomeBlendRadius().setValue(0);
            o.getParticles().setValue(ParticlesMode.MINIMAL);
            o.getEntityShadows().setValue(false);
            o.getGraphicsMode().setValue(GraphicsMode.FAST);
        } else if (saved) {
            o.getViewDistance().setValue(pView);
            o.getBiomeBlendRadius().setValue(pBiome);
            o.getParticles().setValue(pParticles);
            o.getEntityShadows().setValue(pShadows);
            o.getGraphicsMode().setValue(pGraphics);
            saved = false;
        }
    }
}
