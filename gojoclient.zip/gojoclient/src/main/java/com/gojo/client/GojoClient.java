package com.gojo.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public class GojoClient implements ClientModInitializer {
    public static KeyBinding menuKey;
    public static boolean addedNightVision = false;

    @Override
    public void onInitializeClient() {
        Config.load();

        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.gojoclient.menu",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_M,
                KeyBinding.Category.create(Identifier.of("gojoclient", "main"))
        ));

        // HUD (FPS / Ping / CPS / Armor / Potions)
        HudRenderCallback.EVENT.register(Hud::render);

        // Custom crosshair replaces the vanilla one when enabled
        HudElementRegistry.replaceElement(VanillaHudElements.CROSSHAIR, original -> (ctx, tickCounter) -> {
            if (Config.crosshair) {
                Hud.renderCrosshair(ctx);
            } else {
                original.render(ctx, tickCounter);
            }
        });

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (menuKey.wasPressed()) {
                if (mc.currentScreen == null) mc.setScreen(new MenuScreen());
            }
            Hud.tick(mc);
            handleFullbright(mc);
        });

        ClientLifecycleEvents.CLIENT_STARTED.register(mc -> FpsMode.apply(mc));
    }

    // Fullbright = client-side Night Vision (no gamma hacks, no server impact)
    private static void handleFullbright(MinecraftClient mc) {
        if (mc.player == null) {
            addedNightVision = false;
            return;
        }
        if (Config.fullbright) {
            if (!mc.player.hasStatusEffect(StatusEffects.NIGHT_VISION)) {
                mc.player.addStatusEffect(new StatusEffectInstance(
                        StatusEffects.NIGHT_VISION, 1_000_000, 0, false, false, false));
                addedNightVision = true;
            }
        } else if (addedNightVision) {
            mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
            addedNightVision = false;
        }
    }
}
