package com.gojo.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.ItemStack;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;

public class Hud {
    private static final ArrayDeque<Long> LEFT = new ArrayDeque<>();
    private static final ArrayDeque<Long> RIGHT = new ArrayDeque<>();
    private static boolean lastL = false, lastR = false;

    private static final EquipmentSlot[] ARMOR = {
            EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET
    };

    /** Called every client tick: tracks mouse clicks for CPS. */
    public static void tick(MinecraftClient mc) {
        long h = mc.getWindow().getHandle();
        boolean l = GLFW.glfwGetMouseButton(h, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean r = GLFW.glfwGetMouseButton(h, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
        long now = System.currentTimeMillis();
        if (mc.currentScreen == null) {
            if (l && !lastL) LEFT.addLast(now);
            if (r && !lastR) RIGHT.addLast(now);
        }
        lastL = l;
        lastR = r;
        while (!LEFT.isEmpty() && now - LEFT.peekFirst() > 1000) LEFT.pollFirst();
        while (!RIGHT.isEmpty() && now - RIGHT.peekFirst() > 1000) RIGHT.pollFirst();
    }

    public static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden) return;
        TextRenderer tr = mc.textRenderer;

        List<String> stats = new ArrayList<>();
        if (Config.fps) stats.add("FPS: " + mc.getCurrentFps());
        if (Config.ping) stats.add("Ping: " + ping(mc) + " ms");
        if (Config.cps) stats.add("CPS: " + LEFT.size() + " | " + RIGHT.size());

        List<ItemStack> armor = new ArrayList<>();
        if (Config.armor) {
            for (EquipmentSlot s : ARMOR) {
                ItemStack st = mc.player.getEquippedStack(s);
                if (!st.isEmpty()) armor.add(st);
            }
        }

        List<String> potions = new ArrayList<>();
        if (Config.potions) {
            for (StatusEffectInstance e : mc.player.getStatusEffects()) {
                if (GojoClient.addedNightVision
                        && e.getEffectType() == net.minecraft.entity.effect.StatusEffects.NIGHT_VISION) continue;
                String name = e.getEffectType().value().getName().getString();
                if (e.getAmplifier() > 0) name += " " + (e.getAmplifier() + 1);
                potions.add(name + " " + time(e));
            }
        }

        if (stats.isEmpty() && armor.isEmpty() && potions.isEmpty()) return;

        int panelW = 90;
        for (String s : stats) panelW = Math.max(panelW, tr.getWidth(s) + 8);
        for (String s : potions) panelW = Math.max(panelW, tr.getWidth(s) + 8);

        int totalH = stats.size() * 10 + armor.size() * 18 + potions.size() * 10 + 6;
        int sw = ctx.getScaledWindowWidth();
        int sh = ctx.getScaledWindowHeight();

        boolean right = Config.corner == 1 || Config.corner == 3;
        boolean bottom = Config.corner >= 2;
        int x = right ? sw - panelW - 4 : 4;
        int y = bottom ? sh - totalH - 28 : 4;

        ctx.fill(x - 2, y - 2, x + panelW, y + totalH - 2, 0x66000000);

        int cy = y;
        for (String s : stats) {
            ctx.drawTextWithShadow(tr, s, x + 2, cy, 0xFFFFFFFF);
            cy += 10;
        }
        for (ItemStack st : armor) {
            ctx.drawItem(st, x + 2, cy);
            if (st.isDamageable()) {
                int left = st.getMaxDamage() - st.getDamage();
                int color = left * 4 < st.getMaxDamage() ? 0xFFFF5555 : 0xFFAAAAAA;
                ctx.drawTextWithShadow(tr, left + "/" + st.getMaxDamage(), x + 22, cy + 4, color);
            }
            cy += 18;
        }
        for (String s : potions) {
            ctx.drawTextWithShadow(tr, s, x + 2, cy, 0xFF55FFFF);
            cy += 10;
        }
    }

    private static int ping(MinecraftClient mc) {
        if (mc.getNetworkHandler() == null || mc.player == null) return 0;
        PlayerListEntry e = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
        return e == null ? 0 : e.getLatency();
    }

    private static String time(StatusEffectInstance e) {
        if (e.isInfinite()) return "**:**";
        int secs = e.getDuration() / 20;
        return String.format("%d:%02d", secs / 60, secs % 60);
    }

    /** Custom crosshair, drawn in place of the vanilla one. */
    public static void renderCrosshair(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options.hudHidden || !mc.options.getPerspective().isFirstPerson()) return;
        int cx = ctx.getScaledWindowWidth() / 2;
        int cy = ctx.getScaledWindowHeight() / 2;
        int c = Config.COLORS[Config.crossColor];
        switch (Config.crossStyle) {
            case 1 -> ctx.fill(cx - 1, cy - 1, cx + 1, cy + 1, c);
            case 2 -> {
                ctx.fill(cx - 4, cy - 4, cx + 4, cy - 3, c);
                ctx.fill(cx - 4, cy + 3, cx + 4, cy + 4, c);
                ctx.fill(cx - 4, cy - 3, cx - 3, cy + 3, c);
                ctx.fill(cx + 3, cy - 3, cx + 4, cy + 3, c);
            }
            default -> {
                ctx.fill(cx - 6, cy, cx - 2, cy + 1, c);
                ctx.fill(cx + 3, cy, cx + 7, cy + 1, c);
                ctx.fill(cx, cy - 6, cx + 1, cy - 2, c);
                ctx.fill(cx, cy + 3, cx + 1, cy + 7, c);
            }
        }
    }
}
