package com.gojo.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

public class MenuScreen extends Screen {
    public MenuScreen() {
        super(Text.literal("Gojo Client"));
    }

    @Override
    protected void init() {
        int bw = 150;
        int xl = this.width / 2 - bw - 4;
        int xr = this.width / 2 + 4;
        int y0 = 50;
        int step = 24;

        toggle(xl, y0, "FPS", () -> Config.fps, v -> Config.fps = v);
        toggle(xl, y0 + step, "Ping", () -> Config.ping, v -> Config.ping = v);
        toggle(xl, y0 + step * 2, "CPS", () -> Config.cps, v -> Config.cps = v);
        toggle(xl, y0 + step * 3, "Armor Status", () -> Config.armor, v -> Config.armor = v);
        toggle(xl, y0 + step * 4, "Potion Status", () -> Config.potions, v -> Config.potions = v);
        cycle(xl, y0 + step * 5, "HUD Corner", Config.CORNERS, () -> Config.corner, v -> Config.corner = v);

        toggle(xr, y0, "Custom Crosshair", () -> Config.crosshair, v -> Config.crosshair = v);
        toggle(xr, y0 + step, "Fullbright", () -> Config.fullbright, v -> Config.fullbright = v);
        toggle(xr, y0 + step * 2, "FPS Mode", () -> Config.fpsMode, v -> {
            Config.fpsMode = v;
            FpsMode.apply(MinecraftClient.getInstance());
        });
        cycle(xr, y0 + step * 3, "Crosshair Style", Config.STYLES, () -> Config.crossStyle, v -> Config.crossStyle = v);
        cycle(xr, y0 + step * 4, "Crosshair Color", Config.COLOR_NAMES, () -> Config.crossColor, v -> Config.crossColor = v);

        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> this.close())
                .dimensions(this.width / 2 - 75, y0 + step * 6 + 6, 150, 20).build());
    }

    private void toggle(int x, int y, String name, BooleanSupplier get, Consumer<Boolean> set) {
        addDrawableChild(ButtonWidget.builder(label(name, get.getAsBoolean()), b -> {
            boolean n = !get.getAsBoolean();
            set.accept(n);
            b.setMessage(label(name, n));
            Config.save();
        }).dimensions(x, y, 150, 20).build());
    }

    private void cycle(int x, int y, String name, String[] options,
                       java.util.function.IntSupplier get, java.util.function.IntConsumer set) {
        addDrawableChild(ButtonWidget.builder(Text.literal(name + ": " + options[get.getAsInt()]), b -> {
            int n = (get.getAsInt() + 1) % options.length;
            set.accept(n);
            b.setMessage(Text.literal(name + ": " + options[n]));
            Config.save();
        }).dimensions(x, y, 150, 20).build());
    }

    private static Text label(String name, boolean on) {
        return Text.literal(name + ": " + (on ? "ON" : "OFF"));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, 20, 0xFFFFFFFF);
        context.drawCenteredTextWithShadow(this.textRenderer, Text.literal("Press Esc to close"), this.width / 2, 33, 0xFFAAAAAA);
    }
}
