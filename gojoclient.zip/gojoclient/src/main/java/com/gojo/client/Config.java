package com.gojo.client;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

public class Config {
    public static boolean fps = true, ping = true, cps = true, armor = true, potions = true;
    public static boolean crosshair = true, fullbright = false, fpsMode = false;
    public static int corner = 0;      // 0 TL, 1 TR, 2 BL, 3 BR
    public static int crossStyle = 0;  // 0 plus, 1 dot, 2 square
    public static int crossColor = 0;

    public static final String[] CORNERS = {"Top Left", "Top Right", "Bottom Left", "Bottom Right"};
    public static final String[] STYLES = {"Plus", "Dot", "Square"};
    public static final String[] COLOR_NAMES = {"White", "Green", "Red", "Cyan", "Yellow"};
    public static final int[] COLORS = {0xFFFFFFFF, 0xFF55FF55, 0xFFFF5555, 0xFF55FFFF, 0xFFFFFF55};

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("gojoclient.properties");
    }

    public static void load() {
        Path f = file();
        if (!Files.exists(f)) return;
        try (Reader r = Files.newBufferedReader(f)) {
            Properties p = new Properties();
            p.load(r);
            fps = bool(p, "fps", fps);
            ping = bool(p, "ping", ping);
            cps = bool(p, "cps", cps);
            armor = bool(p, "armor", armor);
            potions = bool(p, "potions", potions);
            crosshair = bool(p, "crosshair", crosshair);
            fullbright = bool(p, "fullbright", fullbright);
            fpsMode = bool(p, "fpsMode", fpsMode);
            corner = num(p, "corner", corner, CORNERS.length);
            crossStyle = num(p, "crossStyle", crossStyle, STYLES.length);
            crossColor = num(p, "crossColor", crossColor, COLORS.length);
        } catch (IOException | RuntimeException ignored) {
        }
    }

    public static void save() {
        Properties p = new Properties();
        p.setProperty("fps", String.valueOf(fps));
        p.setProperty("ping", String.valueOf(ping));
        p.setProperty("cps", String.valueOf(cps));
        p.setProperty("armor", String.valueOf(armor));
        p.setProperty("potions", String.valueOf(potions));
        p.setProperty("crosshair", String.valueOf(crosshair));
        p.setProperty("fullbright", String.valueOf(fullbright));
        p.setProperty("fpsMode", String.valueOf(fpsMode));
        p.setProperty("corner", String.valueOf(corner));
        p.setProperty("crossStyle", String.valueOf(crossStyle));
        p.setProperty("crossColor", String.valueOf(crossColor));
        try (Writer w = Files.newBufferedWriter(file())) {
            p.store(w, "Gojo Client");
        } catch (IOException ignored) {
        }
    }

    private static boolean bool(Properties p, String k, boolean d) {
        String v = p.getProperty(k);
        return v == null ? d : Boolean.parseBoolean(v);
    }

    private static int num(Properties p, String k, int d, int max) {
        try {
            int v = Integer.parseInt(p.getProperty(k, String.valueOf(d)));
            return (v >= 0 && v < max) ? v : d;
        } catch (NumberFormatException e) {
            return d;
        }
    }
}
